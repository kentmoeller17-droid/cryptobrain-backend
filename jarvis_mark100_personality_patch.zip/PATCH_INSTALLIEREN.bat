@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

set "TARGET="
if exist "%cd%\app_core\app.py" set "TARGET=%cd%"
if not defined TARGET if exist "%~dp0..\app_core\app.py" set "TARGET=%~dp0.."
if not defined TARGET if exist "%~dp0jarvis_mark100_superbrain\app_core\app.py" set "TARGET=%~dp0jarvis_mark100_superbrain"
if not defined TARGET if exist "%~dp0..\jarvis_mark100_superbrain\app_core\app.py" set "TARGET=%~dp0..\jarvis_mark100_superbrain"

if not defined TARGET (
  echo Zielordner nicht gefunden.
  echo Entpacke den Patch in den Systemordner oder direkt daneben und starte ihn erneut.
  pause
  exit /b 1
)

echo Zielordner: %TARGET%

if not exist "%TARGET%\_patch_backups" mkdir "%TARGET%\_patch_backups"
set "STAMP=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "STAMP=%STAMP: =0%"
mkdir "%TARGET%\_patch_backups\%STAMP%" >nul 2>nul

for %%F in (
app_core\ai.py
app_core\app.py
app_core\sandbox.py
static\js\app.js
static\js\preview.js
static\css\app.css
templates\app.html
) do (
  if exist "%TARGET%\%%F" (
    if not exist "%TARGET%\_patch_backups\%STAMP%\%%~dpF" mkdir "%TARGET%\_patch_backups\%STAMP%\%%~dpF" >nul 2>nul
    copy /y "%TARGET%\%%F" "%TARGET%\_patch_backups\%STAMP%\%%F" >nul
  )
)

xcopy /E /I /Y "payload\*" "%TARGET%\" >nul
if errorlevel 1 (
  echo Patch konnte nicht angewendet werden.
  pause
  exit /b 1
)

echo.
echo Patch erfolgreich angewendet.
echo Neu: besseres Verstehen, mehr Persoenlichkeit, Strukturdiagramm-Tool, robusterer Workspace-Mirror.
pause
