const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || "";
const previewState = { builder: null, chartRows: [] };

async function api(url, options = {}) {
  const init = { ...options, headers: { ...(options.headers || {}), "X-CSRF-Token": csrfToken } };
  const res = await fetch(url, init);
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};
  if (!res.ok || data.ok === false) throw new Error(data.error || data.message || "Request failed");
  return data;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function objectTable(obj) {
  const entries = Object.entries(obj || {});
  if (!entries.length) return `<div class="preview-card muted">Keine Daten</div>`;
  return `<div class="table-wrap"><table class="data-table"><thead><tr><th>Key</th><th>Value</th></tr></thead><tbody>${entries.map(([k,v]) => `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(typeof v === "object" ? JSON.stringify(v) : v)}</td></tr>`).join("")}</tbody></table></div>`;
}

function rowsTable(rows) {
  if (!rows?.length) return `<div class="preview-card muted">Keine Daten</div>`;
  const headers = Object.keys(rows[0]);
  return `<div class="table-wrap"><table class="data-table"><thead><tr>${headers.map(h => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${rows.map(row => `<tr>${headers.map(h => `<td>${escapeHtml(typeof row[h] === "object" ? JSON.stringify(row[h]) : row[h])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

function renderTabs(builder) {
  const shell = document.getElementById("previewTabsShell");
  const tabs = builder.tabs || [];
  if (!tabs.length) {
    shell.hidden = true;
    return;
  }
  shell.hidden = false;
  const root = document.getElementById("previewTabs");
  const detail = document.getElementById("previewDetail");
  let active = tabs[0];
  function renderDetail() {
    if (active === "Konfiguration") detail.innerHTML = (builder.config_rows || []).length ? rowsTable((builder.config_rows || []).slice(0, 800)) : objectTable(builder.config_mirror || {});
    else if (active === "Handelshistorie") detail.innerHTML = rowsTable(builder.trade_history || []);
    else if (active === "Statistiken") detail.innerHTML = objectTable(builder.stats || {});
    else detail.innerHTML = (builder.notes || []).length ? `<div class="preview-card">${(builder.notes || []).map(x => `<div>${escapeHtml(x)}</div>`).join("")}</div>` : "";
  }
  root.innerHTML = tabs.map(tab => `<button class="tab-pill ${tab === active ? "active" : ""}" data-tab="${escapeHtml(tab)}">${escapeHtml(tab)}</button>`).join("");
  root.querySelectorAll(".tab-pill").forEach(btn => btn.addEventListener("click", () => { active = btn.dataset.tab; root.querySelectorAll('.tab-pill').forEach(x => x.classList.toggle('active', x.dataset.tab === active)); renderDetail(); }));
  renderDetail();
}

function drawChart(rows) {
  const canvas = document.getElementById("previewChart");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#070d13";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (!rows?.length) return;
  const closes = rows.map(r => Number(r.close));
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const pad = 28;
  const usableW = canvas.width - pad * 2;
  const usableH = canvas.height - pad * 2;
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const y = pad + (usableH / 3) * i;
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(canvas.width - pad, y);
    ctx.stroke();
  }
  ctx.beginPath();
  closes.forEach((value, index) => {
    const x = pad + (usableW * index) / Math.max(closes.length - 1, 1);
    const y = pad + usableH - ((value - min) / Math.max(max - min || 1, 1)) * usableH;
    if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = "#7dd3fc";
  ctx.lineWidth = 2;
  ctx.stroke();
}

function isBlankBuilder(builder) {
  return !builder || (
    !(builder.meta?.title || builder.meta?.subtitle || builder.meta?.description) &&
    !(builder.chart && Object.keys(builder.chart).length) &&
    !(builder.kpis || []).length &&
    !(builder.panels || []).length &&
    !(builder.tabs || []).length &&
    !(builder.notes || []).length &&
    !(builder.config_rows || []).length &&
    !Object.keys(builder.config_mirror || {}).length &&
    !Object.keys(builder.stats || {}).length
  );
}

async function renderPreview() {
  const res = await api('/api/builder-state');
  const builder = res.state || {};
  previewState.builder = builder;
  const empty = document.getElementById('previewEmpty');
  const content = document.getElementById('previewContent');
  if (isBlankBuilder(builder)) {
    empty.hidden = false;
    content.hidden = true;
    return;
  }
  empty.hidden = true;
  content.hidden = false;
  document.getElementById('previewTitle').textContent = builder.meta?.title || '';
  document.getElementById('previewSubtitle').textContent = builder.meta?.subtitle || '';
  const kpisRoot = document.getElementById('previewKpis');
  kpisRoot.innerHTML = (builder.kpis || []).map(item => `<article class="kpi-card"><div class="kpi-key">${escapeHtml(item.key)}</div><div class="kpi-value">${escapeHtml(item.value)}</div><div class="kpi-note">${escapeHtml(item.note || '')}</div></article>`).join('');
  const panelsRoot = document.getElementById('previewPanels');
  panelsRoot.innerHTML = (builder.panels || []).map(panel => {
    if ((panel.kind || "") === "diagram") {
      return `<article class="panel-card diagram-card"><h4>${escapeHtml(panel.title)}</h4><pre class="diagram-pre">${escapeHtml(panel.body)}</pre></article>`;
    }
    return `<article class="panel-card"><h4>${escapeHtml(panel.title)}</h4><div>${escapeHtml(panel.body).replaceAll("\n","<br>")}</div></article>`;
  }).join('');
  renderTabs(builder);
  const chartWrap = document.getElementById('previewChartWrap');
  const symbol = builder.chart?.symbol || builder.meta?.symbol || '';
  const interval = builder.chart?.interval || builder.meta?.interval || '';
  if (symbol && interval) {
    chartWrap.hidden = false;
    const limit = builder.chart?.limit || 240;
    const data = await api(`/api/binance/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${encodeURIComponent(limit)}`);
    previewState.chartRows = data.rows || [];
    document.getElementById('previewChartMeta').textContent = `${symbol} · ${interval} · ${previewState.chartRows.length} Kerzen`;
    drawChart(previewState.chartRows);
  } else {
    chartWrap.hidden = true;
    document.getElementById('previewChartMeta').textContent = '';
  }
}

renderPreview().catch(err => {
  console.error(err);
});
