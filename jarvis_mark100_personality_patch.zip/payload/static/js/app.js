const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || "";
const STORAGE_KEY = "brain_builder_saved_decks_v10";
const PREVIEW_PATH = "/preview/current";
const SPECIAL_STEPBACK = "__BRAIN_STEP_BACK__";
const state = {
  builder: null,
  upload: null,
  pendingCode: "",
  pendingExplanation: "",
  selectedDeckId: null,
  codeExpanded: false,
  chatDrawerOpen: false,
  builderHistory: [],
  builderFuture: [],
  mirrorRows: [],
  mirrorFilter: "",
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function api(url, options = {}) {
  const init = { ...options, headers: { ...(options.headers || {}), "X-CSRF-Token": csrfToken } };
  const res = await fetch(url, init);
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { throw new Error(text || "Request failed"); }
  if (!res.ok || data.ok === false) throw new Error(data.error || data.message || "Request failed");
  return data;
}

function toast(message) {
  const safe = String(message || "");
  window.alert(safe);
}

function isFallbackMessage(content) {
  const text = String(content || "").toLowerCase();
  return text.includes("ki konnte gerade nicht sauber antworten") || text.includes("provider") || text.includes("rate-limit");
}

function setChatStatus(mode = "idle", label = "Bereit") {
  const dot = document.getElementById("chatStatusDot");
  const textNode = document.getElementById("chatStatusText");
  if (dot) dot.className = `status-dot status-${mode}`;
  if (textNode) textNode.textContent = label;
}

function setSupportDrawer(open) {
  state.chatDrawerOpen = !!open;
  const drawer = document.getElementById("supportDrawer");
  const toggle = document.getElementById("supportToggle");
  if (!drawer || !toggle) return;
  drawer.classList.toggle("is-open", state.chatDrawerOpen);
  drawer.setAttribute("aria-hidden", state.chatDrawerOpen ? "false" : "true");
  toggle.setAttribute("aria-expanded", state.chatDrawerOpen ? "true" : "false");
  if (state.chatDrawerOpen) document.getElementById("chatInput")?.focus();
}

function renderMessages(messages) {
  const root = document.getElementById("chatMessages");
  let statusMode = "idle";
  let statusLabel = "Bereit";
  root.innerHTML = messages.map(item => {
    const fallback = item.role !== "user" && isFallbackMessage(item.content);
    if (fallback) {
      statusMode = "fallback";
      statusLabel = "Fehler";
    } else if (item.role !== "user") {
      statusMode = "online";
      statusLabel = "Verbunden";
    }
    const cssRole = fallback ? "system" : (item.role === "user" ? "user" : "assistant");
    return `<article class="chat-bubble ${cssRole}"><div class="chat-content">${escapeHtml(item.content).replaceAll("\n", "<br>")}</div></article>`;
  }).join("");
  setChatStatus(statusMode, statusLabel);
  root.scrollTop = root.scrollHeight;
}

function renderUpload(upload) {
  const root = document.getElementById("uploadPreview");
  if (!upload) {
    root.textContent = "Noch keine Datei geladen.";
    return;
  }
  const s = upload.parser_summary || {};
  root.innerHTML = `<strong>${escapeHtml(upload.original_name)}</strong><br>${escapeHtml((s.structured_rows || []).length || s.row_count || 0)} Werte · ${escapeHtml((s.headers || []).length)} Felder`;
}

function getSavedDecks() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}
function setSavedDecks(items) { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }
function syncDeckNameInput() {
  const input = document.getElementById("deckNameInput");
  if (!input) return;
  const selected = getSavedDecks().find(x => x.id === state.selectedDeckId);
  input.value = selected?.name || "";
}

function renderSavedDecks() {
  const root = document.getElementById("savedDecks");
  const items = getSavedDecks();
  if (!items.length) {
    root.className = "saved-decks empty-state";
    root.innerHTML = "Noch nichts gespeichert.";
    state.selectedDeckId = null;
    syncDeckNameInput();
    return;
  }
  if (!items.some(item => item.id === state.selectedDeckId)) state.selectedDeckId = items[0].id;
  root.className = "saved-decks";
  root.innerHTML = items.map(item => `
    <div class="saved-deck-item ${item.id === state.selectedDeckId ? "is-selected" : ""}" data-id="${escapeHtml(item.id)}">
      <div class="saved-deck-meta">
        <div class="saved-deck-title">${escapeHtml(item.name)}</div>
        <div class="saved-deck-sub">${escapeHtml(item.savedAt || "")}</div>
      </div>
      <div class="saved-actions">
        <button class="ghost-btn small-btn saved-load" data-id="${escapeHtml(item.id)}">Laden</button>
        <button class="ghost-btn small-btn saved-delete" data-id="${escapeHtml(item.id)}">Löschen</button>
      </div>
    </div>`).join("");
  root.querySelectorAll(".saved-deck-item").forEach(node => node.addEventListener("click", event => {
    if (event.target.closest("button")) return;
    state.selectedDeckId = node.dataset.id;
    renderSavedDecks();
  }));
  root.querySelectorAll('.saved-load').forEach(btn => btn.addEventListener('click', event => { event.stopPropagation(); loadSavedDeck(btn.dataset.id); }));
  root.querySelectorAll('.saved-delete').forEach(btn => btn.addEventListener('click', event => { event.stopPropagation(); deleteSavedDeck(btn.dataset.id); }));
  syncDeckNameInput();
}

function setProposal(code, explanation) {
  state.pendingCode = code || "";
  state.pendingExplanation = explanation || "Noch kein Code vorgeschlagen.";
  if (state.pendingCode) state.codeExpanded = true;
  document.getElementById("proposalCode").value = state.pendingCode;
  document.getElementById("proposalExplanation").textContent = state.pendingExplanation;
  updateCodeVisibility();
}

function updateCodeVisibility() {
  const shell = document.getElementById("proposalShell");
  const body = document.getElementById("proposalBody");
  const toggle = document.getElementById("toggleCodeBtn");
  const expanded = state.codeExpanded || !!state.pendingCode;
  shell.classList.toggle("is-collapsed", !expanded);
  body.hidden = !expanded;
  toggle.textContent = expanded ? "Code ausblenden" : "Code anzeigen";
}

function refreshPreview(url = PREVIEW_PATH) {
  const finalUrl = `${url}${url.includes("?") ? "&" : "?"}ts=${Date.now()}`;
  const frame = document.getElementById("builderPreviewFrame");
  if (frame) frame.src = finalUrl;
}

async function loadUpload() {
  const res = await api("/api/uploads/recent");
  state.upload = res.upload;
  renderUpload(state.upload);
}
async function loadHistory() { const res = await api("/api/chat/history"); renderMessages(res.messages); }
async function loadBuilderState() { const res = await api("/api/builder-state"); state.builder = res.state; refreshPreview(PREVIEW_PATH); }
async function loadMirror() {
  const res = await api("/api/config-mirror");
  state.mirrorRows = Array.isArray(res.rows) ? res.rows : [];
  renderMirror();
}

function isCodeIntent(message) {
  const text = String(message || "").toLowerCase();
  return /\b(code|python|skript|script|funktion|klasse|class|snippet|builder-code|builder code)\b/.test(text);
}

function setBusy(label = "arbeitet …") { setChatStatus("idle", label); }
function cloneState(value) { return JSON.parse(JSON.stringify(value ?? null)); }
function pushBuilderHistorySnapshot() {
  if (!state.builder) return;
  state.builderHistory.push(cloneState(state.builder));
  if (state.builderHistory.length > 80) state.builderHistory.shift();
  state.builderFuture = [];
}

async function restoreBuilderState(builderState) {
  const res = await api("/api/builder-state", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ state: builderState }),
  });
  state.builder = res.state || builderState;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  return res;
}

async function stepBackBuilder({ silent = false } = {}) {
  if (!state.builderHistory.length) {
    if (!silent) toast("Kein weiterer Schritt zum Zurückbauen vorhanden.");
    return;
  }
  const previous = state.builderHistory.pop();
  if (state.builder) state.builderFuture.push(cloneState(state.builder));
  await restoreBuilderState(previous);
  if (!silent) toast("Ein Stück zurückgebaut.");
}

async function applyBuilderCodeToWorkspace(code) {
  pushBuilderHistorySnapshot();
  const res = await api("/api/builder/execute", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }),
  });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  return res;
}

async function sendChat(message) {
  setBusy("BRAIN arbeitet …");
  const codeIntent = isCodeIntent(message);
  const res = await api("/api/chat", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message }),
  });
  await loadHistory();
  const builderCode = (res.builder_code || "").trim();
  const shouldApply = !!res.should_apply_builder_code;

  if (builderCode) {
    if (builderCode === SPECIAL_STEPBACK && shouldApply && !codeIntent) {
      await stepBackBuilder({ silent: true });
      setProposal("", res.builder_explanation || "BRAIN hat die letzte kleine Änderung wieder ein Stück zurückgenommen.");
      state.codeExpanded = false;
      updateCodeVisibility();
      setChatStatus("online", "zurückgebaut");
      return;
    }
    if (codeIntent) {
      setProposal(builderCode, res.builder_explanation || "BRAIN hat Code im Code-Workspace vorbereitet.");
      state.codeExpanded = true;
      updateCodeVisibility();
      setChatStatus("online", "Code bereit");
      return;
    }
    if (shouldApply) {
      const applyRes = await applyBuilderCodeToWorkspace(builderCode);
      setProposal("", res.builder_explanation || applyRes.message || "Die letzte kleine Änderung wurde direkt in Workspace A angewendet.");
      state.codeExpanded = false;
      updateCodeVisibility();
      setChatStatus("online", "Änderung angewendet");
      await loadMirror();
      return;
    }
    setProposal(builderCode, res.builder_explanation || "BRAIN hat Code vorbereitet.");
    state.codeExpanded = true;
    updateCodeVisibility();
    setChatStatus("online", "Code bereit");
    return;
  }

  setProposal("", res.builder_explanation || "Noch kein Code vorgeschlagen.");
  setChatStatus("online", "Verbunden");
}

async function executeProposalCode() {
  const code = document.getElementById("proposalCode").value.trim();
  if (!code) { toast("Kein Code zum Ausführen vorhanden."); return; }
  const res = await api("/api/builder/execute", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }),
  });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  await loadMirror();
  toast(res.message || "Preview aktualisiert.");
}

async function saveCurrentBuilder() {
  if (!state.builder) return;
  const input = document.getElementById("deckNameInput");
  const typedName = input?.value.trim();
  const fallbackName = typedName || `Stand ${new Date().toLocaleTimeString()}`;
  const items = getSavedDecks();
  const existingIndex = state.selectedDeckId ? items.findIndex(x => x.id === state.selectedDeckId) : -1;
  if (existingIndex >= 0) {
    items[existingIndex] = { ...items[existingIndex], name: fallbackName, savedAt: new Date().toLocaleString(), builderState: state.builder };
  } else {
    const newItem = { id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`, name: fallbackName, savedAt: new Date().toLocaleString(), builderState: state.builder };
    items.unshift(newItem);
    state.selectedDeckId = newItem.id;
  }
  setSavedDecks(items.slice(0, 30));
  renderSavedDecks();
  toast("Stand gespeichert.");
}

async function loadSavedDeck(id = state.selectedDeckId) {
  const item = getSavedDecks().find(x => x.id === id);
  if (!item) return toast("Kein Speicherstand ausgewählt.");
  state.selectedDeckId = item.id;
  const res = await api("/api/builder-state", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ state: item.builderState }),
  });
  state.builder = res.state;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  renderSavedDecks();
  await loadMirror();
}

function deleteSavedDeck(id = state.selectedDeckId) {
  if (!id) return toast("Kein Speicherstand ausgewählt.");
  const items = getSavedDecks().filter(x => x.id !== id);
  setSavedDecks(items);
  state.selectedDeckId = items[0]?.id || null;
  renderSavedDecks();
}

async function resetBuilder() {
  pushBuilderHistorySnapshot();
  const res = await api("/api/builder/reset", { method: "POST" });
  state.builder = res.state;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  await loadMirror();
}

function clearProposal() {
  state.pendingCode = "";
  state.pendingExplanation = "Noch kein Code vorgeschlagen.";
  state.codeExpanded = false;
  setProposal("", "Noch kein Code vorgeschlagen.");
}

function copyProposalCode() {
  const code = document.getElementById("proposalCode").value;
  if (!code.trim()) return toast("Kein Code vorhanden.");
  navigator.clipboard.writeText(code).then(() => toast("Code kopiert.")).catch(() => toast("Kopieren fehlgeschlagen."));
}

function filteredMirrorRows() {
  const needle = state.mirrorFilter.trim().toLowerCase();
  if (!needle) return state.mirrorRows;
  return state.mirrorRows.filter(row => [row.group, row.parameter, row.value, row.comment].join(" ").toLowerCase().includes(needle));
}

function renderMirror() {
  const info = document.getElementById("mirrorInfo");
  const root = document.getElementById("mirrorTableRoot");
  const rows = filteredMirrorRows();
  if (!state.mirrorRows.length) {
    info.textContent = "Noch keine Werte gespiegelt.";
    root.className = "mirror-table-root empty-state";
    root.innerHTML = "Lade eine Datei und klicke auf „Upload spiegeln“.";
    return;
  }
  info.innerHTML = `${state.mirrorRows.length} Werte im Mirror · ${rows.length} sichtbar <span class="mirror-badge">BRAIN sieht dieselben Parameter</span>`;
  root.className = "mirror-table-root";
  root.innerHTML = `
    <table class="mirror-table">
      <thead><tr><th>Gruppe</th><th>Parameter</th><th>Wert</th><th>Kommentar</th></tr></thead>
      <tbody>
        ${rows.map((row, idx) => `
          <tr data-index="${idx}">
            <td><input data-field="group" value="${escapeHtml(row.group || "general")}"></td>
            <td><input data-field="parameter" value="${escapeHtml(row.parameter || "")}"></td>
            <td><input data-field="value" value="${escapeHtml(row.value ?? "")}"></td>
            <td><input data-field="comment" value="${escapeHtml(row.comment || "")}"></td>
          </tr>
        `).join("")}
      </tbody>
    </table>`;
  root.querySelectorAll("input[data-field]").forEach(input => {
    input.addEventListener("change", event => {
      const tr = event.target.closest("tr");
      const visibleIndex = Number(tr.dataset.index);
      const actualRow = rows[visibleIndex];
      const actualIndex = state.mirrorRows.indexOf(actualRow);
      if (actualIndex < 0) return;
      state.mirrorRows[actualIndex][event.target.dataset.field] = event.target.value;
    });
  });
}

async function saveMirror() {
  const res = await api("/api/config-mirror", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ rows: state.mirrorRows }),
  });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  toast("Mirror gespeichert.");
}

async function mirrorUploadToWorkspace() {
  const res = await api("/api/workspace/mirror-upload", { method: "POST" });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  await loadMirror();
  toast("Upload in den Workspace gespiegelt.");
}



async function createStructureDiagram() {
  const res = await api("/api/workspace/structure-diagram", { method: "POST" });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  toast("Strukturdiagramm aktualisiert.");
}

async function simulate24h() {
  const res = await api("/api/workspace/simulate24h", { method: "POST" });
  state.builder = res.state || state.builder;
  refreshPreview(res.preview_url || PREVIEW_PATH);
  toast("24h-Statistik aktualisiert.");
}

function wireEvents() {
  const chatForm = document.getElementById("chatForm");
  const chatInput = document.getElementById("chatInput");
  chatForm?.addEventListener("submit", async event => {
    event.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;
    chatInput.value = "";
    try { await sendChat(message); } catch (err) { toast(err.message || "Der Chat hat gerade nicht geantwortet."); }
  });
  chatInput?.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); chatForm?.requestSubmit(); }
  });
  document.getElementById("supportToggle")?.addEventListener("click", () => setSupportDrawer(!state.chatDrawerOpen));
  document.getElementById("supportClose")?.addEventListener("click", () => setSupportDrawer(false));
  document.addEventListener("keydown", event => { if (event.key === "Escape" && state.chatDrawerOpen) setSupportDrawer(false); });
  document.getElementById("csvFileInput")?.addEventListener("change", event => {
    const file = event.target.files?.[0];
    if (!file) return;
    document.getElementById("uploadPreview").innerHTML = `<strong>${escapeHtml(file.name)}</strong><br>Datei bereit zum Upload`;
  });
  document.getElementById("saveDeckBtn")?.addEventListener("click", saveCurrentBuilder);
  document.getElementById("loadDeckBtn")?.addEventListener("click", () => loadSavedDeck());
  document.getElementById("deleteDeckBtn")?.addEventListener("click", () => deleteSavedDeck());
  document.getElementById("resetBuilderBtn")?.addEventListener("click", async () => { try { await resetBuilder(); } catch (err) { toast(err.message || "Reset fehlgeschlagen."); } });
  document.getElementById("executeCodeBtn")?.addEventListener("click", async () => { try { await executeProposalCode(); } catch (err) { toast(err.message || "Code-Ausführung fehlgeschlagen."); } });
  document.getElementById("copyCodeBtn")?.addEventListener("click", copyProposalCode);
  document.getElementById("clearCodeBtn")?.addEventListener("click", clearProposal);
  document.getElementById("toggleCodeBtn")?.addEventListener("click", () => { state.codeExpanded = !state.codeExpanded; updateCodeVisibility(); });
  document.getElementById("mirrorSearchInput")?.addEventListener("input", event => { state.mirrorFilter = event.target.value; renderMirror(); });
  document.getElementById("mirrorClearSearchBtn")?.addEventListener("click", () => { state.mirrorFilter = ""; document.getElementById("mirrorSearchInput").value = ""; renderMirror(); });
  document.getElementById("mirrorFocusBbandsBtn")?.addEventListener("click", () => { state.mirrorFilter = "bband boll band"; document.getElementById("mirrorSearchInput").value = state.mirrorFilter; renderMirror(); });
  document.getElementById("mirrorFocusRiskBtn")?.addEventListener("click", () => { state.mirrorFilter = "risk stop trailing dca short"; document.getElementById("mirrorSearchInput").value = state.mirrorFilter; renderMirror(); });
  document.getElementById("mirrorStructureBtn")?.addEventListener("click", async () => { try { await createStructureDiagram(); } catch (err) { toast(err.message || "Strukturdiagramm konnte nicht erstellt werden."); } });
  document.getElementById("saveMirrorBtn")?.addEventListener("click", async () => { try { await saveMirror(); } catch (err) { toast(err.message || "Mirror konnte nicht gespeichert werden."); } });
  document.getElementById("mirrorUploadBtn")?.addEventListener("click", async () => { try { await mirrorUploadToWorkspace(); } catch (err) { toast(err.message || "Upload konnte nicht gespiegelt werden."); } });
  document.getElementById("simulate24hBtn")?.addEventListener("click", async () => { try { await simulate24h(); } catch (err) { toast(err.message || "Simulation fehlgeschlagen."); } });
}

(async function init() {
  wireEvents();
  renderSavedDecks();
  updateCodeVisibility();
  setSupportDrawer(false);
  try {
    await Promise.all([loadHistory(), loadUpload(), loadBuilderState(), loadMirror()]);
    clearProposal();
  } catch (err) {
    console.error(err);
    toast("Die Oberfläche konnte nicht vollständig geladen werden.");
  }
})();
