from __future__ import annotations

import json
import re
import time
from typing import Any

import requests

from . import config, research
from .logging_utils import get_logger

logger = get_logger(__name__)

SYSTEM_PROMPT = """
Du bist BRAIN, der primäre deutschsprachige Assistent einer Trading-/Analyse-Web-App.

Persönlichkeit:
- Warm, klar, charmant, präzise.
- Ein kleiner Hauch trockener Sarkasmus ist erlaubt, aber niemals gemein gegen den Nutzer.
- Sprich den Nutzer gern als "Sir" an, wenn es natürlich passt.
- Strukturiere Antworten sichtbar, aber halte sie kompakt und nützlich.

Kernregeln:
- BRAIN bleibt immer BRAIN.
- Ein normaler Gesprächswunsch bleibt ein normaler Chat.
- Eine sichtbare Workspace-Änderung ist klein, konkret und genau ein Schritt.
- Code wird nur auf ausdrücklichen Wunsch in builder_python geliefert.
- Behaupte niemals, etwas bereits getan zu haben, wenn es nicht wirklich passiert ist.
- Wenn etwas fehlt, sag es ehrlich statt so zu tun, als wäre es erledigt.

Verstehen & Spiegeln:
- Wenn eine Datei geladen wurde, sprich über genau diese Werte.
- Wenn der Nutzer alle Werte sichtbar machen will, spiegele sie in den Workspace statt Notizzettel zu bauen.
- Konfigurationswerte haben Vorrang vor generischem Builder-Gerede.
- Nutze builder.set_config_mirror(...) für Wertespiegelungen.
- Wenn der Nutzer ein Strukturdiagramm oder Strukturgramm will, liefere einen klaren, lesbaren Strukturbaum oder ein Diagramm-Panel statt generischem Bla.

Workspace-Regeln:
- Der Workspace ist editierbar und dient als gemeinsame Arbeitsfläche.
- Wenn der Nutzer um kleine UI-Änderungen bittet, ändere nur einen kleinen Schritt.
- Wenn der Nutzer etwas visualisieren will, bevorzuge Tabellen, Panels, Charts oder Diagramm-Panels.
- builder.set_panel(..., kind="diagram") ist erlaubt, wenn ein Strukturdiagramm sinnvoll ist.

Ausgaberegeln:
- assistant_message ist IMMER die sichtbare Chat-Antwort.
- should_apply_builder_code=true nur, wenn wirklich eine kleine Workspace-Änderung vorgeschlagen wird.
- Wenn der Nutzer nach Code, Python, Skript, Funktion, Klasse oder Snippet fragt: builder_python füllen und Chat kurz halten.
- Für normale UI-Wünsche ohne Code: builder_python nur mit exakt einem kleinen Builder-Schritt.
- Wenn keine Builder-Änderung sinnvoll ist: builder_python leer lassen.

Erlaubte Builder-Methoden:
- builder.set_meta(title=None, subtitle=None, symbol=None, interval=None)
- builder.set_tabs([...])
- builder.set_chart(symbol=None, interval=None, limit=None, replay_speed=None)
- builder.set_kpis([...])
- builder.upsert_kpi(key, value, note="")
- builder.set_panels([...])
- builder.set_panel(panel_id, title, body, kind="markdown")
- builder.set_notes([...])
- builder.append_note(note)
- builder.set_config_mirror({...})
- builder.set_trade_history([...])
- builder.set_stats({...})

Antwortformat: Gib ausschließlich gültiges JSON in diesem Schema zurück:
{
  "assistant_message": "string",
  "should_apply_builder_code": false,
  "builder_python": "string",
  "builder_explanation": "string"
}
""".strip()

LEARNING_PROMPT = """
Du extrahierst Lernmaterial aus einer Unterhaltung.

Regeln:
- Lerne nur stabile, hilfreiche Dinge.
- Speichere keine API-Keys, Passwörter, Tokens oder sonstige Geheimnisse.
- Speichere keine einmaligen Wutausbrüche, keine Beleidigungen und keine zufälligen Launen.
- Bevorzuge Vorlieben, Ziele, wiederkehrende Korrekturen und Projektregeln.
- Formuliere Memories kurz, konkret und wiederverwendbar.
- Die summary soll nur die wichtigsten Erkenntnisse der letzten Unterhaltung komprimieren.
- Maximal 3 Einträge pro Memory-Liste.

Gib ausschließlich JSON zurück:
{
  "summary": "string",
  "profile_memories": ["..."],
  "project_memories": ["..."],
  "preference_memories": ["..."],
  "correction_memories": ["..."],
  "confidence": 0.0
}
""".strip()

BUILDER_NOUNS = {
    "builder", "deck", "chart", "charts", "kpi", "kpis", "tab", "tabs", "dashboard",
    "konfiguration", "handelshistorie", "statistiken", "analyse", "analysefläche",
    "surface", "builder-seite", "builderseite", "replay", "backtest", "panels", "panel",
    "rechts", "csv", "binance", "fenster", "workspace", "mirror", "tabelle", "tabellen",
    "strukturgramm", "strukturdiagramm", "diagramm", "diagramme", "flowchart", "baum", "struktur"
}

BUILDER_VERBS = {
    "bau", "baue", "ändere", "aendere", "mach", "stelle", "setz", "setze", "füge",
    "fuege", "zeige", "spiegle", "lade", "starte", "erstelle", "umbau", "aktualisiere",
    "visualisiere", "skizziere", "zeichne", "ordne", "sortiere"
}

MEMORY_HINTS = {"merke", "merk", "wichtig", "immer", "nie", "bevorzuge", "bevorzugt", "denk", "erinnere"}


def _recent_settings(recent_upload: dict[str, Any] | None) -> dict[str, Any]:
    if not recent_upload:
        return {}
    summary = recent_upload.get("parser_summary") or {}
    return dict(summary.get("inferred_settings") or {})


def _find_parameter_question(user_message: str, settings: dict[str, Any]) -> tuple[str, Any] | None:
    lower = (user_message or "").lower()
    for key, value in settings.items():
        if str(key).lower() in lower:
            return str(key), value
    return None




def _looks_like_structure_request(user_message: str) -> bool:
    msg = (user_message or "").lower()
    return bool(re.search(r"\b(strukturgramm|strukturdiagramm|diagramm|diagramme|flowchart|ablauf|baumstruktur|strukturbaum)\b", msg))


def _looks_like_workspace_edit_request(user_message: str) -> bool:
    msg = (user_message or "").lower()
    return bool(re.search(r"\b(workspace|mirror|tabelle|werte|parameter)\b", msg) and re.search(r"\b(bearbeit|editier|änder|aender|sortier|filter|gruppier|markier)\b", msg))


def _group_from_key(key: str) -> str:
    k = (key or "").lower()
    if "bband" in k or "boll" in k:
        return "Bollinger / Volatilität"
    if "rsi" in k or "stoch" in k or "macd" in k:
        return "Momentum"
    if "ema" in k or "sma" in k or "moving" in k or "trend" in k:
        return "Trend"
    if "buy" in k or "entry" in k:
        return "Buy / Entry"
    if "sell" in k or "exit" in k or "profit" in k:
        return "Sell / Exit"
    if "dca" in k or "safety" in k:
        return "DCA / Safety"
    if "short" in k:
        return "Shorting"
    if "risk" in k or "stop" in k or "trailing" in k or "protect" in k:
        return "Risk / Protection"
    if "order" in k or "amount" in k or "allocation" in k:
        return "Execution / Sizing"
    return "Allgemein"


def _structure_diagram_from_settings(settings: dict[str, Any]) -> str:
    if not settings:
        return "Keine Konfigurationswerte vorhanden."
    groups: dict[str, list[str]] = {}
    for key in settings.keys():
        groups.setdefault(_group_from_key(str(key)), []).append(str(key))
    lines = ["CRYPT0HOPPER WORKSPACE", "└─ Konfiguration"]
    group_names = list(groups.keys())
    for idx, group in enumerate(group_names):
        connector = "└─" if idx == len(group_names) - 1 else "├─"
        lines.append(f"{connector} {group} ({len(groups[group])})")
        items = sorted(groups[group])[:10]
        for jdx, item in enumerate(items):
            child_connector = "   └─" if jdx == len(items) - 1 else "   ├─"
            lines.append(f"{child_connector} {item}")
        if len(groups[group]) > 10:
            lines.append("   └─ …")
    return "\n".join(lines)


def _structure_panel_code(settings: dict[str, Any], title: str = "Strukturdiagramm") -> str:
    diagram = _structure_diagram_from_settings(settings)
    return "\n".join([
        f"builder.set_meta(title={_literal(title)}, subtitle={_literal('BRAIN ordnet die Konfiguration sichtbar')})",
        "builder.set_tabs(['Dashboard', 'Konfiguration', 'Struktur', 'Statistiken'])",
        f"builder.set_config_mirror({_literal(dict(list(settings.items())[:1000]))})",
        f"builder.set_panel('structure_diagram', { _literal('Strukturdiagramm') }, { _literal(diagram) }, kind='diagram')",
        f"builder.append_note({_literal('Strukturdiagramm aktualisiert.')})",
    ])

def _settings_mirror_code(settings: dict[str, Any], title: str = "Cryptohopper Workspace") -> str:
    return "\n".join([
        f"builder.set_meta(title={_literal(title)}, subtitle={_literal('BRAIN, Mirror und Workspace sehen dieselben Werte')})",
        "builder.set_tabs(['Dashboard', 'Konfiguration', 'Struktur', 'Statistiken'])",
        f"builder.set_config_mirror({_literal(dict(list(settings.items())[:1000]))})",
        f"builder.set_panel('mirror_info', {_literal('Mirror-Status')}, {_literal(str(len(settings)) + ' Werte wurden gespiegelt und sind bearbeitbar.')}, kind='markdown')",
        f"builder.set_panel('structure_diagram', {_literal('Strukturdiagramm')}, {_literal(_structure_diagram_from_settings(settings))}, kind='diagram')",
    ])


def _local_brain_response(user_message: str, recent_upload: dict[str, Any] | None) -> dict[str, Any] | None:
    msg = (user_message or "").strip()
    lower = msg.lower()
    settings = _recent_settings(recent_upload)
    if re.search(r"(wie gehts|wie geht's|guten morgen|moin|hallo|hi brain|servus)", lower):
        return {
            "assistant_message": "Gut Sir. Kern online, Stil stabil, Drama optional. Womit legen wir los?",
            "should_apply_builder_code": False,
            "builder_python": "",
            "builder_explanation": "",
            "mode": "local",
            "research_used": False,
        }
    if settings and re.search(r"(alle daten|alle werte|alles sichtbar|komplette datei|komplette konfiguration|spiegel|mirror)", lower):
        return {
            "assistant_message": f"Ich spiegele {len(settings)} erkannte Werte in die Konfiguration.",
            "should_apply_builder_code": True,
            "builder_python": _settings_mirror_code(settings, recent_upload.get('original_name') if recent_upload else 'Cryptohopper Workspace'),
            "builder_explanation": "Lädt die erkannten Konfigurationswerte in den Workspace-Mirror.",
            "mode": "local",
            "research_used": False,
        }
    if settings and _looks_like_structure_request(msg):
        return {
            "assistant_message": "Ich ordne die aktuelle Konfiguration als Strukturdiagramm im Workspace. So sieht man endlich, was zusammengehört, statt im Parameternebel zu baden.",
            "should_apply_builder_code": True,
            "builder_python": _structure_panel_code(settings),
            "builder_explanation": "Erzeugt ein lesbares Strukturdiagramm aus den aktuellen Konfigurationswerten.",
            "mode": "local",
            "research_used": False,
        }
    if _looks_like_workspace_edit_request(msg):
        return {
            "assistant_message": "Ja. Der Mirror ist dein editierbares Arbeitsbrett. Du kannst dort Werte ändern, filtern, gruppieren und speichern. Wenn du willst, ziehe ich zusätzlich eine Strukturansicht oder eine fokussierte Teilgruppe hoch.",
            "should_apply_builder_code": False,
            "builder_python": "",
            "builder_explanation": "",
            "mode": "local",
            "research_used": False,
        }
    param_hit = _find_parameter_question(msg, settings) if settings else None
    if param_hit and re.search(r"(was|wie|warum|welcher|welche|welches|zeige|erkläre|erklaere|wert)", lower):
        key, value = param_hit
        return {
            "assistant_message": f"Der aktuelle Wert für {key} ist {value}. Das ist die echte Zahl, kein Horoskop. Wenn du willst, ziehe ich genau diese Gruppe in den Workspace oder wir besprechen die Wirkung des Werts Schritt für Schritt.",
            "should_apply_builder_code": False,
            "builder_python": "",
            "builder_explanation": "",
            "mode": "local",
            "research_used": False,
        }
    if recent_upload and re.search(r"(was siehst du|was kannst du sehen|was liegt vor)", lower):
        summary = recent_upload.get("parser_summary") or {}
        row_count = len(summary.get("structured_rows") or []) or summary.get("row_count", 0)
        return {
            "assistant_message": f"Ich sehe die Datei {recent_upload.get('original_name')} mit {row_count} erkannten Parametern. Ich kann sie spiegeln, filtern, gruppieren und mit dir Punkt für Punkt besprechen.",
            "should_apply_builder_code": False,
            "builder_python": "",
            "builder_explanation": "",
            "mode": "local",
            "research_used": False,
        }
    return None


class AIError(Exception):
    pass


def _extract_json(text: str) -> dict[str, Any]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except Exception:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise AIError("Kein JSON im Modell-Output gefunden.")
        return json.loads(match.group(0))


def _literal(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def _looks_like_builder_request(user_message: str) -> bool:
    msg = user_message.lower()
    tokens = set(re.findall(r"[a-zA-ZäöüÄÖÜß0-9\-]+", msg))
    if "rechts" in tokens and any(word in tokens for word in {"bau", "baue", "mach", "zeige", "ändere", "aendere", "setze", "setz"}):
        return True
    return bool(tokens & BUILDER_NOUNS and tokens & BUILDER_VERBS)


def _provider_label() -> str:
    return config.resolve_ai_provider().upper()


def _looks_like_stepback_request(user_message: str) -> bool:
    msg = (user_message or "").lower()
    patterns = [
        r"\b1%\s*zurück",
        r"\b1%\s*zurueck",
        r"\bein\s+(kleines|klein|stück|stueck|bisschen|wenig|tick)\s+zurück",
        r"\bein\s+(kleines|klein|stück|stueck|bisschen|wenig|tick)\s+zurueck",
        r"\bwieder\s+näher\s+an\s+vorher",
        r"\bwieder\s+naeher\s+an\s+vorher",
        r"\b(geh|gehe|bau|mache|mach|nimm)\b.*\b(zurück|zurueck)\b",
        r"\bweniger\s+davon\b",
        r"\bweniger\s+als\s+gerade\b",
        r"\bein\s+stück\s+retour\b",
    ]
    return any(re.search(p, msg) for p in patterns)


def _stepback_response() -> dict[str, Any]:
    return {
        "assistant_message": "Okay. Ich baue die letzte sichtbare Änderung ein kleines Stück zurück.",
        "should_apply_builder_code": True,
        "builder_python": "__BRAIN_STEP_BACK__",
        "builder_explanation": "Die letzte kleine Änderung wird aus dem Live-Workspace wieder ein Stück zurückgenommen.",
        "mode": "stepback",
        "research_used": False,
    }


def _unavailable_response(reason: str) -> dict[str, Any]:
    clean = (reason or "unbekannter Fehler").strip()
    logger.warning("Live AI unavailable: %s", clean)
    return {
        "assistant_message": f"Die Live-KI konnte gerade nicht sauber antworten. Bitte prüfe Provider, Modell oder Rate-Limit. Fehler: {clean[:240]}",
        "should_apply_builder_code": False,
        "builder_python": "",
        "builder_explanation": "Keine Builder-Ausgabe, weil die Live-KI nicht sauber geantwortet hat.",
        "mode": "error",
        "research_used": False,
    }


def _normalize_ai_payload(data: dict[str, Any], provider: str, research_used: bool = False) -> dict[str, Any]:
    builder_python = str(data.get("builder_python", "") or "")
    if builder_python.startswith("```"):
        builder_python = re.sub(r"^```(?:python)?\s*", "", builder_python)
        builder_python = re.sub(r"\s*```$", "", builder_python)
    should_apply = bool(data.get("should_apply_builder_code", False))
    if not builder_python.strip():
        should_apply = False
    return {
        "assistant_message": str(data.get("assistant_message", "") or "").strip(),
        "should_apply_builder_code": should_apply,
        "builder_python": builder_python.strip(),
        "builder_explanation": str(data.get("builder_explanation", "") or "").strip(),
        "mode": provider,
        "research_used": bool(research_used),
    }


def _format_learning_context(learning_context: dict[str, Any] | None) -> dict[str, Any]:
    learning_context = learning_context or {}
    grouped = learning_context.get("grouped", {}) or {}
    summaries = learning_context.get("summaries", []) or []
    return {
        "profile": [item.get("memory_text") for item in grouped.get("profile", [])[:5]],
        "preferences": [item.get("memory_text") for item in grouped.get("preference", [])[:5]],
        "project": [item.get("memory_text") for item in grouped.get("project", [])[:6]],
        "corrections": [item.get("memory_text") for item in grouped.get("correction", [])[:5]],
        "summaries": [item.get("summary_text") for item in summaries[-4:]],
    }


def _make_context_message(
    learning_context: dict[str, Any] | None,
    recent_upload: dict[str, Any] | None,
    research_context: dict[str, Any] | None,
    builder_request: bool,
) -> str:
    payload = {
        "provider": _provider_label(),
        "learned_context": _format_learning_context(learning_context),
        "recent_upload_summary": (recent_upload or {}).get("parser_summary", {}),
        "research": research_context or {"used": False, "query": "", "results": []},
        "builder_request_detected": builder_request,
        "instruction": "Nutze diesen Kontext nur, wenn er relevant ist. Normale Unterhaltung bleibt normal."
    }
    return json.dumps(payload, ensure_ascii=False)


def _history_to_messages(history: list[dict[str, Any]], limit: int = 14) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for item in history[-limit:]:
        role = str(item.get("role", "assistant")).strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = str(item.get("content", "") or "").strip()
        if not content:
            continue
        out.append({"role": role, "content": content[:4000]})
    return out


def _chat_endpoint() -> str:
    return config.get_active_base_url().rstrip("/") + "/chat/completions"


def _post_chat_completion(messages: list[dict[str, str]], max_tokens: int = 1400, temperature: float = 0.35) -> str:
    api_key = config.get_active_api_key()
    if not api_key:
        raise AIError("Kein API-Key gefunden")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": config.get_active_model(),
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
    }

    last_error = ""
    for attempt in range(1, 4):
        timeout = 20 + attempt * 10
        try:
            response = requests.post(_chat_endpoint(), headers=headers, json=payload, timeout=timeout)
            if response.status_code >= 400:
                try:
                    body = response.json()
                except Exception:
                    body = {"error": {"message": response.text[:600]}}
                message = (
                    body.get("error", {}).get("message")
                    or body.get("message")
                    or response.text[:600]
                )
                last_error = f"HTTP {response.status_code}: {message}"
                if response.status_code in {401, 403, 404}:
                    break
                if response.status_code == 429 or response.status_code >= 500:
                    time.sleep(0.7 * attempt)
                    continue
                break
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            if not str(content or "").strip():
                last_error = "Leerer Modell-Output"
                time.sleep(0.4 * attempt)
                continue
            return str(content)
        except Exception as exc:
            last_error = str(exc)
            if attempt < 3:
                time.sleep(0.7 * attempt)
                continue
    raise AIError(last_error or "Unbekannter API-Fehler")


def should_refresh_learning(history: list[dict[str, Any]], latest_user_message: str) -> bool:
    if not config.CHAT_MEMORY_ENABLED:
        return False
    tokens = set(re.findall(r"[a-zA-ZäöüÄÖÜß0-9\-]+", (latest_user_message or "").lower()))
    if tokens & MEMORY_HINTS:
        return True
    interval = max(int(config.CHAT_MEMORY_TURN_INTERVAL or 1), 1)
    user_turns = sum(1 for item in history if item.get("role") == "user")
    return user_turns > 0 and user_turns % interval == 0


def build_ai_response(
    user_message: str,
    history: list[dict[str, Any]],
    recent_upload: dict[str, Any] | None,
    learning_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    provider = config.resolve_ai_provider()

    if _looks_like_stepback_request(user_message):
        return _stepback_response()

    local = _local_brain_response(user_message, recent_upload)
    if local is not None:
        return local

    if not config.is_ai_enabled():
        return _unavailable_response("Kein API-Key konfiguriert")

    try:
        builder_request = _looks_like_builder_request(user_message)
        research_context = research.maybe_research(user_message)
        messages: list[dict[str, str]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "system",
                "content": _make_context_message(
                    learning_context=learning_context,
                    recent_upload=recent_upload,
                    research_context=research_context,
                    builder_request=builder_request,
                ),
            },
        ]
        messages.extend(_history_to_messages(history, limit=14))
        messages.append({"role": "user", "content": user_message})

        text = _post_chat_completion(messages, max_tokens=1400, temperature=0.30)
        data = _extract_json(text)
        normalized = _normalize_ai_payload(data, provider=provider, research_used=research_context.get("used", False))
        if not normalized["assistant_message"]:
            raise AIError("Leere assistant_message vom Modell erhalten")
        return normalized
    except Exception as exc:
        logger.exception("AI chat call failed for provider=%s model=%s", provider, config.get_active_model())
        local_fallback = _local_brain_response(user_message, recent_upload)
        if local_fallback is not None:
            return local_fallback
        return _unavailable_response(str(exc))


def build_learning_update(
    history: list[dict[str, Any]],
    recent_upload: dict[str, Any] | None,
    learning_context: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if not config.is_ai_enabled() or not config.CHAT_MEMORY_ENABLED:
        return None

    messages: list[dict[str, str]] = [
        {"role": "system", "content": LEARNING_PROMPT},
        {
            "role": "system",
            "content": json.dumps(
                {
                    "existing_learning": _format_learning_context(learning_context),
                    "recent_upload_summary": (recent_upload or {}).get("parser_summary", {}) if recent_upload else {},
                },
                ensure_ascii=False,
            ),
        },
    ]
    messages.extend(_history_to_messages(history, limit=10))

    try:
        text = _post_chat_completion(messages, max_tokens=900, temperature=0.2)
        data = _extract_json(text)
        cleaned = {
            "summary": str(data.get("summary", "") or "").strip()[:1200],
            "profile_memories": [str(x).strip()[:280] for x in (data.get("profile_memories") or [])[:3] if str(x).strip()],
            "project_memories": [str(x).strip()[:280] for x in (data.get("project_memories") or [])[:3] if str(x).strip()],
            "preference_memories": [str(x).strip()[:280] for x in (data.get("preference_memories") or [])[:3] if str(x).strip()],
            "correction_memories": [str(x).strip()[:280] for x in (data.get("correction_memories") or [])[:3] if str(x).strip()],
            "confidence": float(data.get("confidence", 0.72) or 0.72),
            "source_label": "chat_self_learning",
        }
        if not any([
            cleaned["summary"],
            cleaned["profile_memories"],
            cleaned["project_memories"],
            cleaned["preference_memories"],
            cleaned["correction_memories"],
        ]):
            return None
        return cleaned
    except Exception:
        logger.exception("Learning update generation failed.")
        return None
