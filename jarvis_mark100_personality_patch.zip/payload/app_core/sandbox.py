from __future__ import annotations

import ast
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from . import config, db
from .builder_state import load_state, save_state
from .logging_utils import get_logger

logger = get_logger(__name__)

BANNED_NAMES = {
    "open",
    "exec",
    "eval",
    "compile",
    "input",
    "globals",
    "locals",
    "vars",
    "getattr",
    "setattr",
    "delattr",
    "__import__",
    "help",
    "dir",
    "type",
    "object",
    "super",
    "memoryview",
    "bytearray",
    "classmethod",
    "staticmethod",
}

ALLOWED_NODES = {
    ast.Module,
    ast.Expr,
    ast.Assign,
    ast.Name,
    ast.Load,
    ast.Store,
    ast.Constant,
    ast.Dict,
    ast.List,
    ast.Tuple,
    ast.keyword,
    ast.Call,
    ast.Attribute,
    ast.BinOp,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Mod,
    ast.Compare,
    ast.Eq,
    ast.NotEq,
    ast.Gt,
    ast.GtE,
    ast.Lt,
    ast.LtE,
    ast.BoolOp,
    ast.And,
    ast.Or,
    ast.UnaryOp,
    ast.USub,
    ast.UAdd,
    ast.Not,
    ast.JoinedStr,
    ast.FormattedValue,
}

ALLOWED_BUILDER_METHODS = {
    "set_meta",
    "set_tabs",
    "set_chart",
    "set_kpis",
    "upsert_kpi",
    "set_panels",
    "set_panel",
    "set_notes",
    "append_note",
    "set_config_mirror",
    "set_trade_history",
    "set_stats",
}

MAX_CODE_CHARS = 9000
MAX_CODE_LINES = 120


class SandboxViolation(Exception):
    pass


@dataclass
class SandboxResult:
    ok: bool
    message: str
    state: dict[str, Any] | None = None
    code_file: str | None = None


class BuilderAPI:
    def __init__(self, state: dict[str, Any]):
        self.state = state

    def set_meta(self, title: str | None = None, subtitle: str | None = None, symbol: str | None = None, interval: str | None = None) -> None:
        meta = self.state.setdefault("meta", {})
        if title is not None:
            meta["title"] = str(title)
        if subtitle is not None:
            meta["subtitle"] = str(subtitle)
        if symbol is not None:
            meta["symbol"] = str(symbol).upper()
            self.state.setdefault("chart", {})["symbol"] = str(symbol).upper()
        if interval is not None:
            meta["interval"] = str(interval)
            self.state.setdefault("chart", {})["interval"] = str(interval)

    def set_tabs(self, tabs: list[str]) -> None:
        self.state["tabs"] = [str(t) for t in tabs][:8]

    def set_chart(self, symbol: str | None = None, interval: str | None = None, limit: int | None = None, replay_speed: int | None = None) -> None:
        chart = self.state.setdefault("chart", {})
        if symbol is not None:
            chart["symbol"] = str(symbol).upper()
            self.state.setdefault("meta", {})["symbol"] = str(symbol).upper()
        if interval is not None:
            chart["interval"] = str(interval)
            self.state.setdefault("meta", {})["interval"] = str(interval)
        if limit is not None:
            chart["limit"] = max(20, min(int(limit), 1000))
        if replay_speed is not None:
            chart["replay_speed"] = max(1, min(int(replay_speed), 100))

    def set_kpis(self, kpis: list[dict[str, Any]] | list[str]) -> None:
        cleaned = []
        for item in kpis[:24]:
            if isinstance(item, dict):
                cleaned.append(
                    {
                        "key": str(item.get("key", "KPI")),
                        "value": str(item.get("value", "-")),
                        "note": str(item.get("note", "")),
                    }
                )
            else:
                cleaned.append({"key": str(item), "value": "-", "note": ""})
        self.state["kpis"] = cleaned

    def upsert_kpi(self, key: str, value: Any, note: str = "") -> None:
        key = str(key)
        items = self.state.setdefault("kpis", [])
        for item in items:
            if item.get("key") == key:
                item["value"] = str(value)
                item["note"] = str(note)
                return
        items.append({"key": key, "value": str(value), "note": str(note)})

    def set_panels(self, panels: list[dict[str, Any]] | list[str]) -> None:
        cleaned = []
        for panel in panels[:24]:
            if isinstance(panel, dict):
                cleaned.append(
                    {
                        "id": str(panel.get("id", uuid4().hex[:8])),
                        "title": str(panel.get("title", "Panel")),
                        "kind": str(panel.get("kind", "markdown")),
                        "body": str(panel.get("body", "")),
                    }
                )
            else:
                cleaned.append({"id": uuid4().hex[:8], "title": str(panel), "kind": "markdown", "body": ""})
        self.state["panels"] = cleaned

    def set_panel(self, panel_id: str, title: str, body: str, kind: str = "markdown") -> None:
        items = self.state.setdefault("panels", [])
        for item in items:
            if item.get("id") == panel_id:
                item.update({"title": str(title), "body": str(body), "kind": str(kind)})
                return
        items.append({"id": str(panel_id), "title": str(title), "body": str(body), "kind": str(kind)})

    def set_notes(self, notes: list[str]) -> None:
        self.state["notes"] = [str(n) for n in notes][:50]

    def set_config_mirror(self, mapping: dict[str, Any]) -> None:
        self.state["config_mirror"] = {str(k): mapping[k] for k in list(mapping.keys())[:1000]}

    def set_trade_history(self, rows: list[dict[str, Any]]) -> None:
        self.state["trade_history"] = rows[:200]

    def set_stats(self, stats: dict[str, Any]) -> None:
        self.state["stats"] = {str(k): stats[k] for k in list(stats.keys())[:100]}

    def append_note(self, note: str) -> None:
        self.state.setdefault("notes", []).append(str(note))


def _validate_ast(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if type(node) not in ALLOWED_NODES:
            raise SandboxViolation(f"Verbotener AST-Knoten: {type(node).__name__}")
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if not isinstance(target, ast.Name):
                    raise SandboxViolation("Zuweisungen sind nur an lokale Variablen erlaubt.")
                if target.id in {"builder", "data"}:
                    raise SandboxViolation(f"Reservierter Name darf nicht überschrieben werden: {target.id}")
        if isinstance(node, ast.Attribute) and str(node.attr).startswith("__"):
            raise SandboxViolation("Dunder-Attribute sind verboten.")
        if isinstance(node, ast.Name) and node.id in BANNED_NAMES:
            raise SandboxViolation(f"Verbotener Name: {node.id}")
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Attribute):
                raise SandboxViolation("Nur Aufrufe auf builder.<methode>(...) sind erlaubt.")
            if not isinstance(node.func.value, ast.Name) or node.func.value.id != "builder":
                raise SandboxViolation("Nur das Objekt builder darf Methoden aufrufen.")
            if node.func.attr not in ALLOWED_BUILDER_METHODS:
                raise SandboxViolation(f"Builder-Methode nicht erlaubt: {node.func.attr}")


def _persist_generated_code(code: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    file_name = f"builder_job_{ts}_{uuid4().hex[:8]}.py"
    target = config.BUILDER_GENERATED_DIR / file_name
    target.write_text(code, encoding="utf-8")
    return file_name


def run_builder_code(code: str, user_id: int, extra_context: dict[str, Any] | None = None) -> SandboxResult:
    code = code.strip()
    code_file = _persist_generated_code(code)

    if len(code) > MAX_CODE_CHARS:
        db.add_audit_log(user_id, "builder", "sandbox_validate", "blocked", {"error": "code_too_large", "code_file": code_file})
        return SandboxResult(ok=False, message="Sandbox blockiert den Builder-Code: zu groß.", code_file=code_file)
    if len([line for line in code.splitlines() if line.strip()]) > MAX_CODE_LINES:
        db.add_audit_log(user_id, "builder", "sandbox_validate", "blocked", {"error": "too_many_lines", "code_file": code_file})
        return SandboxResult(ok=False, message="Sandbox blockiert den Builder-Code: zu viele Zeilen.", code_file=code_file)

    try:
        tree = ast.parse(code, mode="exec")
        _validate_ast(tree)
    except Exception as exc:
        db.add_audit_log(user_id, "builder", "sandbox_validate", "blocked", {"error": str(exc), "code_file": code_file})
        logger.warning("Sandbox blocked code: %s", exc)
        return SandboxResult(ok=False, message=f"Sandbox blockiert den Builder-Code: {exc}", code_file=code_file)

    state = load_state()
    builder = BuilderAPI(state)
    exec_globals = {
        "__builtins__": {},
        "builder": builder,
        "data": extra_context or {},
        "True": True,
        "False": False,
        "None": None,
    }

    try:
        compiled = compile(tree, code_file, "exec")
        exec(compiled, exec_globals, {})
        new_state = save_state(builder.state)
        db.add_audit_log(user_id, "builder", "sandbox_execute", "success", {"code_file": code_file})
        return SandboxResult(ok=True, message="Builder aktualisiert.", state=new_state, code_file=code_file)
    except Exception as exc:
        db.add_audit_log(user_id, "builder", "sandbox_execute", "error", {"error": str(exc), "code_file": code_file})
        logger.exception("Sandbox execution failed")
        return SandboxResult(ok=False, message=f"Builder-Code konnte nicht ausgeführt werden: {exc}", code_file=code_file)
