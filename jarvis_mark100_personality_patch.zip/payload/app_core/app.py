from __future__ import annotations

from typing import Any

from flask import Flask, Response, flash, g, jsonify, redirect, render_template, request, session, url_for

from . import ai, auth, binance_client, builder_state, config, csv_tools, db
from .auth import AuthError
from .logging_utils import get_logger, setup_logging
from .sandbox import run_builder_code

logger = get_logger(__name__)


def _group_from_key(key: str) -> str:
    k = (key or "").lower()
    if "bband" in k or "boll" in k:
        return "Bollinger / Volatilität"
    if "rsi" in k or "stoch" in k or "macd" in k:
        return "Momentum"
    if "ema" in k or "sma" in k or "trend" in k:
        return "Trend"
    if "buy" in k or "entry" in k:
        return "Buy / Entry"
    if "sell" in k or "exit" in k or "profit" in k:
        return "Sell / Exit"
    if "dca" in k or "safety" in k:
        return "DCA / Safety"
    if "short" in k:
        return "Shorting"
    if "risk" in k or "stop" in k or "trailing" in k:
        return "Risk / Protection"
    if "order" in k or "amount" in k or "allocation" in k:
        return "Execution / Sizing"
    return "Allgemein"


def _structure_diagram_from_rows(rows: list[dict[str, Any]], mapping: dict[str, Any]) -> str:
    if not rows and not mapping:
        return "Keine Konfigurationswerte vorhanden."
    groups: dict[str, list[str]] = {}
    if rows:
        for row in rows:
            parameter = str(row.get("parameter", "") or "").strip()
            if not parameter:
                continue
            group = str(row.get("group", "") or "").strip() or _group_from_key(parameter)
            groups.setdefault(group, []).append(parameter)
    else:
        for key in mapping.keys():
            groups.setdefault(_group_from_key(str(key)), []).append(str(key))
    lines = ["CRYPT0HOPPER WORKSPACE", "└─ Konfiguration"]
    group_names = list(groups.keys())
    for idx, group in enumerate(group_names):
        connector = "└─" if idx == len(group_names) - 1 else "├─"
        lines.append(f"{connector} {group} ({len(groups[group])})")
        items = sorted(groups[group])[:10]
        for jdx, item in enumerate(items):
            child_connector = "   └─" if jdx == len(items) - 1 else "   ├─"
            lines.append(f"{child_connector} {item}")
        if len(groups[group]) > 10:
            lines.append("   └─ …")
    return "\n".join(lines)



def _system_status() -> dict[str, Any]:
    return {
        "version": config.APP_VERSION,
        "env_loaded": config.ENV_LOADED,
        "ai_enabled": config.is_ai_enabled(),
        "ai_provider": config.resolve_ai_provider(),
        "ai_model": config.get_active_model(),
        "ai_base_url": config.get_active_base_url(),
        "chat_memory_enabled": config.CHAT_MEMORY_ENABLED,
        "chat_memory_interval": config.CHAT_MEMORY_TURN_INTERVAL,
        "chat_research_enabled": config.CHAT_RESEARCH_ENABLED,
        "database_path": str(config.DATABASE_PATH),
        "builder_state_file": str(config.BUILDER_STATE_FILE),
        "host": config.HOST,
        "port": config.PORT,
        "debug": config.DEBUG,
    }


def _validate_builder_state(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise AuthError("Ungültiger Builder-State.")
    state = builder_state.DEFAULT_STATE | payload
    state.setdefault("meta", builder_state.DEFAULT_STATE["meta"])
    state.setdefault("tabs", builder_state.DEFAULT_STATE["tabs"])
    state.setdefault("kpis", builder_state.DEFAULT_STATE["kpis"])
    state.setdefault("chart", builder_state.DEFAULT_STATE["chart"])
    state.setdefault("panels", builder_state.DEFAULT_STATE["panels"])
    state.setdefault("config_mirror", {})
    state.setdefault("config_rows", [])
    state.setdefault("trade_history", [])
    state.setdefault("stats", {})
    state.setdefault("notes", [])
    return state


def create_app() -> Flask:
    setup_logging()
    db.init_db()
    db.bootstrap_admin()
    builder_state.ensure_state_file()

    app = Flask(
        __name__,
        template_folder=str(config.TEMPLATES_DIR),
        static_folder=str(config.STATIC_DIR),
    )
    app.config.update(
        SECRET_KEY=config.SECRET_KEY,
        SESSION_COOKIE_NAME=config.SESSION_COOKIE_NAME,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE=config.SESSION_COOKIE_SAMESITE,
        SESSION_COOKIE_SECURE=config.SESSION_COOKIE_SECURE,
        MAX_CONTENT_LENGTH=config.MAX_UPLOAD_BYTES,
    )

    @app.before_request
    def _load_user() -> None:
        auth.load_current_user()
        auth.ensure_csrf_token()

    @app.context_processor
    def inject_globals() -> dict[str, Any]:
        return {
            "current_user": getattr(g, "current_user", None),
            "csrf_token": session.get("csrf_token", ""),
            "app_name": config.APP_NAME,
            "app_version": config.APP_VERSION,
        }

    @app.errorhandler(AuthError)
    def handle_auth_error(exc: AuthError):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": str(exc)}), 400
        flash(str(exc), "error")
        return redirect(request.referrer or url_for("login"))

    @app.errorhandler(413)
    def handle_file_too_large(_exc):
        message = f"Datei zu groß. Maximal {config.MAX_UPLOAD_MB} MB erlaubt."
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": message}), 413
        flash(message, "error")
        return redirect(request.referrer or url_for("app_view"))

    @app.errorhandler(Exception)
    def handle_unexpected_error(exc: Exception):
        logger.exception("Unhandled application error")
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": f"Interner Fehler: {exc}"}), 500
        flash(f"Interner Fehler: {exc}", "error")
        return redirect(request.referrer or url_for("app_view" if getattr(g, "current_user", None) else "login"))

    @app.get("/")
    def index():
        if getattr(g, "current_user", None):
            return redirect(url_for("app_view"))
        return redirect(url_for("login"))

    @app.get("/health")
    def health():
        return jsonify({"ok": True, "status": "healthy", "system": _system_status()})

    @app.get("/api/system/status")
    @auth.login_required
    def api_system_status():
        return jsonify({"ok": True, "system": _system_status()})

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            auth.verify_csrf()
            username = request.form.get("username", "")
            password = request.form.get("password", "")
            user_id = auth.register_user(username, password)
            db.add_audit_log(user_id, "auth", "register", "success", {"username": username})
            flash("Registrierung erfolgreich. Bitte einloggen.", "success")
            return redirect(url_for("login"))
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            auth.verify_csrf()
            username = request.form.get("username", "")
            password = request.form.get("password", "")
            auth.login_user(username, password)
            user = db.query_one("SELECT id, username, is_admin FROM users WHERE username = ?", (username,))
            db.add_audit_log(user["id"] if user else None, "auth", "login", "success", {"username": username})
            return redirect(url_for("app_view"))
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        auth.verify_csrf()
        user = getattr(g, "current_user", None)
        if user:
            db.add_audit_log(user["id"], "auth", "logout", "success", {})
        auth.logout_user()
        flash("Abgemeldet.", "success")
        return redirect(url_for("login"))

    @app.get("/app")
    @auth.login_required
    def app_view():
        return render_template("app.html")

    @app.get("/preview/current")
    @auth.login_required
    def preview_current():
        return render_template("preview.html")

    @app.get("/admin")
    @auth.admin_required
    def admin_view():
        snapshot = db.get_admin_snapshot()
        return render_template("admin.html", snapshot=snapshot, system=_system_status())

    @app.post("/upload")
    @auth.login_required
    def upload():
        auth.verify_csrf()
        file = request.files.get("file")
        if not file or not file.filename:
            raise AuthError("Keine Datei ausgewählt.")
        if not csv_tools.allowed_file(file.filename):
            raise AuthError("Nur CSV, TXT oder JSON erlaubt.")

        target, original_name, bytes_size = csv_tools.save_upload(file)
        summary = csv_tools.parse_csv_file(target)
        upload_id = db.add_upload(
            g.current_user["id"],
            target.name,
            original_name,
            file.content_type or "application/octet-stream",
            bytes_size,
            summary,
        )
        db.add_audit_log(g.current_user["id"], "upload", "upload_csv", "success", {"upload_id": upload_id, "name": original_name})
        flash(f"Datei {original_name} hochgeladen und geparst.", "success")
        return redirect(url_for("app_view"))

    @app.get("/api/chat/history")
    @auth.login_required
    def api_chat_history():
        return jsonify({"ok": True, "messages": db.get_chat_history(g.current_user["id"], limit=40)})

    @app.post("/api/chat")
    @auth.login_required
    def api_chat():
        auth.verify_csrf()
        payload = request.get_json(silent=True) or {}
        message = str(payload.get("message", "")).strip()
        if not message:
            return jsonify({"ok": False, "error": "Nachricht fehlt."}), 400

        user_id = int(g.current_user["id"])
        db.add_chat_message(user_id, "user", message)
        history = db.get_chat_history(user_id, limit=18)
        recent_upload = db.get_recent_upload(user_id)
        learning_context = db.get_learning_context(user_id)

        ai_response = ai.build_ai_response(message, history, recent_upload, learning_context=learning_context)
        assistant_message = ai_response.get("assistant_message", "")
        db.add_chat_message(user_id, "assistant", assistant_message)
        history_after_reply = db.get_chat_history(user_id, limit=20)

        learning_counts = {"summary": 0, "memories": 0}
        if ai_response.get("mode") not in {"fallback", "error"} and ai.should_refresh_learning(history_after_reply, message):
            learning_payload = ai.build_learning_update(history_after_reply, recent_upload, learning_context=learning_context)
            if learning_payload:
                learning_counts = db.save_learning_payload(user_id, learning_payload)

        db.add_audit_log(
            user_id,
            "ai",
            "chat_turn",
            "success",
            {
                "builder_code_proposed": bool(ai_response.get("builder_python")),
                "reply_mode": ai_response.get("mode", "unknown"),
                "research_used": bool(ai_response.get("research_used", False)),
                "learning_summary_saved": learning_counts.get("summary", 0),
                "learning_memories_saved": learning_counts.get("memories", 0),
            },
        )
        return jsonify(
            {
                "ok": True,
                "reply": assistant_message,
                "builder_code": ai_response.get("builder_python", ""),
                "builder_explanation": ai_response.get("builder_explanation", ""),
                "should_apply_builder_code": bool(ai_response.get("should_apply_builder_code", False)),
                "reply_mode": ai_response.get("mode", "unknown"),
            }
        )

    @app.get("/api/builder-state")
    @auth.login_required
    def api_builder_state():
        return jsonify({"ok": True, "state": builder_state.load_state()})

    @app.post("/api/builder-state")
    @auth.login_required
    def api_builder_state_update():
        auth.verify_csrf()
        payload = request.get_json(silent=True) or {}
        incoming_state = _validate_builder_state(payload.get("state") or {})
        state = builder_state.save_state(incoming_state)
        db.add_audit_log(g.current_user["id"], "builder", "load_saved_state", "success", {"revision": state.get("revision")})
        return jsonify({"ok": True, "state": state, "preview_url": url_for("preview_current", _external=False)})

    @app.post("/api/builder/execute")
    @auth.login_required
    def api_builder_execute():
        auth.verify_csrf()
        payload = request.get_json(silent=True) or {}
        code = str(payload.get("code", "") or "").strip()
        if not code:
            return jsonify({"ok": False, "error": "Kein Builder-Code übergeben."}), 400
        recent_upload = db.get_recent_upload(g.current_user["id"])
        current_state = builder_state.load_state()
        extra_context = {
            "symbol": current_state.get("meta", {}).get("symbol", "BTCUSDT"),
            "interval": current_state.get("meta", {}).get("interval", "1m"),
            "csv_settings": (recent_upload or {}).get("parser_summary", {}).get("inferred_settings", {}),
        }
        builder_result = run_builder_code(code, g.current_user["id"], extra_context=extra_context)
        if not builder_result.ok:
            return jsonify({"ok": False, "error": builder_result.message}), 400
        db.add_audit_log(
            g.current_user["id"],
            "builder",
            "execute_builder_code",
            "success",
            {"message": builder_result.message},
        )
        return jsonify({"ok": True, "message": builder_result.message, "state": builder_result.state, "preview_url": url_for("preview_current", _external=False)})

    @app.post("/api/builder/reset")
    @auth.login_required
    def api_builder_reset():
        auth.verify_csrf()
        state = builder_state.reset_state()
        db.add_audit_log(g.current_user["id"], "builder", "reset_builder", "success", {})
        return jsonify({"ok": True, "state": state, "preview_url": url_for("preview_current", _external=False)})



    @app.get("/api/config-mirror")
    @auth.login_required
    def api_config_mirror():
        state = builder_state.load_state()
        rows = list(state.get("config_rows") or [])
        mapping = dict(state.get("config_mirror") or {})
        upload = db.get_recent_upload(g.current_user["id"])
        if not rows and upload:
            summary = upload.get("parser_summary") or {}
            rows = list(summary.get("structured_rows") or [])
            if not mapping:
                mapping = dict(summary.get("inferred_settings") or {})
        return jsonify({"ok": True, "rows": rows, "mapping": mapping})

    @app.post("/api/config-mirror")
    @auth.login_required
    def api_config_mirror_update():
        auth.verify_csrf()
        payload = request.get_json(silent=True) or {}
        rows = list(payload.get("rows") or [])[:3000]
        cleaned_rows = []
        mapping = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            parameter = str(row.get("parameter", "") or "").strip()
            if not parameter:
                continue
            value = row.get("value")
            cleaned = {
                "group": str(row.get("group", "general") or "general"),
                "parameter": parameter,
                "value": value,
                "type": str(row.get("type", type(value).__name__)),
                "source": str(row.get("source", "workspace")),
                "comment": str(row.get("comment", "") or ""),
            }
            cleaned_rows.append(cleaned)
            mapping[parameter] = value
        state = builder_state.load_state()
        state["config_rows"] = cleaned_rows
        state["config_mirror"] = mapping
        tabs = list(state.get("tabs") or [])
        if "Konfiguration" not in tabs:
            tabs.insert(0, "Konfiguration")
        state["tabs"] = tabs[:8]
        if not state.get("meta", {}).get("title"):
            state.setdefault("meta", {})["title"] = "Workspace Mirror"
            state["meta"]["subtitle"] = "BRAIN und Workspace sehen dieselben Werte"
        saved = builder_state.save_state(state)
        db.add_audit_log(g.current_user["id"], "workspace", "save_config_mirror", "success", {"rows": len(cleaned_rows)})
        return jsonify({"ok": True, "state": saved, "preview_url": url_for("preview_current", _external=False)})

    @app.post("/api/workspace/mirror-upload")
    @auth.login_required
    def api_workspace_mirror_upload():
        auth.verify_csrf()
        upload = db.get_recent_upload(g.current_user["id"])
        if not upload:
            return jsonify({"ok": False, "error": "Noch keine Datei geladen."}), 400
        summary = upload.get("parser_summary") or {}
        state = builder_state.load_state()
        state.setdefault("meta", {})["title"] = upload.get("original_name") or "Workspace Mirror"
        state["meta"]["subtitle"] = f"{len(summary.get('structured_rows') or [])} Parameter gespiegelt"
        state["config_rows"] = list(summary.get("structured_rows") or [])[:3000]
        state["config_mirror"] = dict(summary.get("inferred_settings") or {})
        tabs = list(state.get("tabs") or [])
        for tab in ["Dashboard", "Konfiguration", "Statistiken"]:
            if tab not in tabs:
                tabs.append(tab)
        state["tabs"] = tabs[:8]
        if not state.get("notes"):
            state["notes"] = list(summary.get("notes") or [])
        saved = builder_state.save_state(state)
        db.add_audit_log(g.current_user["id"], "workspace", "mirror_upload", "success", {"upload_id": upload.get("id"), "rows": len(state["config_rows"])})
        return jsonify({"ok": True, "state": saved, "preview_url": url_for("preview_current", _external=False)})

    @app.post("/api/workspace/simulate24h")
    @auth.login_required
    def api_workspace_simulate24h():
        auth.verify_csrf()
        state = builder_state.load_state()
        symbol = (state.get("meta", {}) or {}).get("symbol") or request.args.get("symbol", "BTCUSDT")
        try:
            candles = binance_client.get_klines(symbol, "1h", 24)
        except Exception:
            candles = []
        config_map = dict(state.get("config_mirror") or {})
        seed = max(len(config_map), 1)
        closes = [float(row.get("close", 0) or 0) for row in candles] or [1.0]
        hi = max(closes)
        lo = min(closes)
        drift = ((closes[-1] - closes[0]) / closes[0] * 100.0) if len(closes) > 1 and closes[0] else 0.0
        simulated = {
            "Gewinn": f"{round(drift * max(seed / 25.0, 0.8), 2)}%",
            "Umsatz": round(sum(closes[-8:]) * max(seed / 6.0, 1.0), 2),
            "Käufe": max(seed // 8, 1),
            "Verkäufe": max(seed // 10, 1),
            "Range 24h": round(hi - lo, 4),
            "Signalstärke": round(min(99.0, 35 + seed / 3.0), 2),
        }
        state["stats"] = simulated
        tabs = list(state.get("tabs") or [])
        if "Statistiken" not in tabs:
            tabs.append("Statistiken")
        state["tabs"] = tabs[:8]
        saved = builder_state.save_state(state)
        db.add_audit_log(g.current_user["id"], "workspace", "simulate24h", "success", {"symbol": symbol, "stats": simulated})
        return jsonify({"ok": True, "stats": simulated, "state": saved, "preview_url": url_for("preview_current", _external=False)})



@app.post("/api/workspace/structure-diagram")
@auth.login_required
def api_workspace_structure_diagram():
    auth.verify_csrf()
    state = builder_state.load_state()
    rows = list(state.get("config_rows") or [])
    mapping = dict(state.get("config_mirror") or {})
    if not rows and not mapping:
        upload = db.get_recent_upload(g.current_user["id"])
        summary = (upload or {}).get("parser_summary") or {}
        rows = list(summary.get("structured_rows") or [])
        mapping = dict(summary.get("inferred_settings") or {})
    if not rows and not mapping:
        return jsonify({"ok": False, "error": "Keine Konfigurationswerte für ein Strukturdiagramm gefunden."}), 400
    diagram = _structure_diagram_from_rows(rows, mapping)
    panels = list(state.get("panels") or [])
    panel = {"id": "structure_diagram", "title": "Strukturdiagramm", "kind": "diagram", "body": diagram}
    replaced = False
    for idx, item in enumerate(panels):
        if item.get("id") == "structure_diagram":
            panels[idx] = panel
            replaced = True
            break
    if not replaced:
        panels.insert(0, panel)
    state["panels"] = panels[:24]
    tabs = list(state.get("tabs") or [])
    for tab in ["Dashboard", "Konfiguration", "Struktur", "Statistiken"]:
        if tab not in tabs:
            tabs.append(tab)
    state["tabs"] = tabs[:8]
    state.setdefault("meta", {})["subtitle"] = "Mirror, Struktur und Workspace greifen sauber ineinander"
    saved = builder_state.save_state(state)
    db.add_audit_log(g.current_user["id"], "workspace", "structure_diagram", "success", {"rows": len(rows), "mapping": len(mapping)})
    return jsonify({"ok": True, "state": saved, "preview_url": url_for("preview_current", _external=False)})

    @app.get("/api/uploads/recent")
    @auth.login_required
    def api_upload_recent():
        return jsonify({"ok": True, "upload": db.get_recent_upload(g.current_user["id"])})

    @app.get("/api/binance/klines")
    @auth.login_required
    def api_binance_klines():
        symbol = request.args.get("symbol", "BTCUSDT")
        interval = request.args.get("interval", "1m")
        limit = int(request.args.get("limit", 240))
        rows = binance_client.get_klines(symbol, interval, limit)
        return jsonify({"ok": True, "rows": rows})

    @app.get("/api/binance/ticker")
    @auth.login_required
    def api_binance_ticker():
        symbol = request.args.get("symbol", "BTCUSDT")
        return jsonify({"ok": True, "ticker": binance_client.get_ticker(symbol)})

    @app.get("/robots.txt")
    def robots() -> Response:
        return Response("User-agent: *\nDisallow: /\n", mimetype="text/plain")

    return app
